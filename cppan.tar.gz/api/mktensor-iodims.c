#include "guru.h"
#include "mktensor-iodims.h"
