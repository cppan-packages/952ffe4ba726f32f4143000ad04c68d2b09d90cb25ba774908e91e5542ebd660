/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-avx-128-fma.h"
#include "../common/n1bv_5.c"
