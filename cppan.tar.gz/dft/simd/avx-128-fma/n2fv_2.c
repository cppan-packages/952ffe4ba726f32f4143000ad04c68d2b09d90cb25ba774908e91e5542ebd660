/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-avx-128-fma.h"
#include "../common/n2fv_2.c"
