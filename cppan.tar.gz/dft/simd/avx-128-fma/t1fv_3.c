/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-avx-128-fma.h"
#include "../common/t1fv_3.c"
