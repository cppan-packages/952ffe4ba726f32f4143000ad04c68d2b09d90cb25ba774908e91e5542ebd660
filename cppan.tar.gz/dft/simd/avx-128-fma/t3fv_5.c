/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-avx-128-fma.h"
#include "../common/t3fv_5.c"
