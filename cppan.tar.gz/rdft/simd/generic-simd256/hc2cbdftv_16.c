/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-generic256.h"
#include "../common/hc2cbdftv_16.c"
