/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-vsx.h"
#include "../common/hc2cbdftv_4.c"
